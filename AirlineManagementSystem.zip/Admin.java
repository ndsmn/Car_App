import java.util.Date;

public class Admin extends User {
    public Admin() {
        super(1, "admin", "admin123", 0, "admin@ams.com", new Date());
        this.role = "Admin";
    }
}