import java.util.Date;

public class FlightBooking {
    private int bookingId;
    private int flightId;
    private int userId;
    private String seatCategory;
    private int ticketCount;
    private Date bookingDate;
    private Date travelDate;
    private double totalFare;
    private double refundAmount;

    public FlightBooking(int bookingId, int flightId, int userId, String seatCategory, int ticketCount,
                         Date bookingDate, Date travelDate, double totalFare) {
        this.bookingId = bookingId;
        this.flightId = flightId;
        this.userId = userId;
        this.seatCategory = seatCategory;
        this.ticketCount = ticketCount;
        this.bookingDate = bookingDate;
        this.travelDate = travelDate;
        this.totalFare = totalFare;
    }

    public int getBookingId() { return bookingId; }
    public double getTotalFare() { return totalFare; }
}