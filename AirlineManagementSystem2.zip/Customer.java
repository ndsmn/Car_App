import java.util.Date;

public class Customer extends User {
    public Customer(int userId, String userName, String password, long phone, String emailId, Date dob) {
        super(userId, userName, password, phone, emailId, dob);
        this.role = "Customer";
    }

    public void editProfile(String userName, String password, long phone, String emailId,
                            String address1, String address2, String city, String state,
                            String country, long zipCode, Date dob) {
        this.userName = userName;
        this.password = password;
        this.phone = phone;
        this.emailId = emailId;
        this.address1 = address1;
        this.address2 = address2;
        this.city = city;
        this.state = state;
        this.country = country;
        this.zipCode = zipCode;
        this.dob = dob;
    }
}