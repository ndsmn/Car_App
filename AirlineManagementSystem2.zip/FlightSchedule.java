import java.util.Date;

public class FlightSchedule {
    private int flightId;
    private Date travelDate;

    public FlightSchedule(int flightId, Date travelDate) {
        this.flightId = flightId;
        this.travelDate = travelDate;
    }

    public int getFlightId() { return flightId; }
    public Date getTravelDate() { return travelDate; }
}