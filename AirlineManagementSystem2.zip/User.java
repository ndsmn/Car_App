import java.util.Date;

public class User {
    protected int userId;
    protected String userName;
    protected String password;
    protected long phone;
    protected String emailId;
    protected String address1;
    protected String address2;
    protected String city;
    protected String state;
    protected String country;
    protected long zipCode;
    protected Date dob;
    protected String role;
    protected String userCategory;

    public User(int userId, String userName, String password, long phone, String emailId, Date dob) {
        this.userId = userId;
        this.userName = userName;
        this.password = password;
        this.phone = phone;
        this.emailId = emailId;
        this.dob = dob;
        this.role = "Customer";
        this.userCategory = "";
    }

    public int getUserId() { return userId; }
    public String getUserName() { return userName; }
    public String getPassword() { return password; }
    public String getRole() { return role; }
    public String getUserCategory() { return userCategory; }
}