public class Carrier {
    private int carrierId;
    private String carrierName;
    private int discount30;
    private int discount60;
    private int discount90;
    private int bulkDiscount;
    private int refund2;
    private int refund10;
    private int refund20;
    private int silverDiscount;
    private int goldDiscount;
    private int platinumDiscount;

    public Carrier(int carrierId, String carrierName, int discount30, int discount60, int discount90,
                   int bulkDiscount, int refund2, int refund10, int refund20,
                   int silverDiscount, int goldDiscount, int platinumDiscount) {
        this.carrierId = carrierId;
        this.carrierName = carrierName;
        this.discount30 = discount30;
        this.discount60 = discount60;
        this.discount90 = discount90;
        this.bulkDiscount = bulkDiscount;
        this.refund2 = refund2;
        this.refund10 = refund10;
        this.refund20 = refund20;
        this.silverDiscount = silverDiscount;
        this.goldDiscount = goldDiscount;
        this.platinumDiscount = platinumDiscount;
    }

    public int getCarrierId() { return carrierId; }
    public String getCarrierName() { return carrierName; }
}