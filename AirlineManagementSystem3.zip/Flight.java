public class Flight {
    private int flightId;
    private int carrierId;
    private String source;
    private String destination;
    private double baseFare;

    public Flight(int flightId, int carrierId, String source, String destination, double baseFare) {
        this.flightId = flightId;
        this.carrierId = carrierId;
        this.source = source;
        this.destination = destination;
        this.baseFare = baseFare;
    }

    public int getFlightId() { return flightId; }
    public int getCarrierId() { return carrierId; }
    public double getBaseFare() { return baseFare; }
}