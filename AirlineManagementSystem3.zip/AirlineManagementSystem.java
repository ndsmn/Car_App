import java.util.*;
import java.text.*;

public class AirlineManagementSystem {
    static Scanner scanner = new Scanner(System.in);
    static Admin admin = new Admin();
    static List<Customer> customers = new ArrayList<>();
    static List<Carrier> carriers = new ArrayList<>();
    static List<Flight> flights = new ArrayList<>();
    static List<FlightSchedule> schedules = new ArrayList<>();
    static List<FlightBooking> bookings = new ArrayList<>();
    static int customerCounter = 1000, carrierCounter = 100, flightCounter = 500, bookingCounter = 2000;

    public static void main(String[] args) {
        while (true) {
            System.out.println("\nWelcome to Airline Management System - AMS");
            System.out.println("1. Admin Sign-in");
            System.out.println("2. Customer Sign-in");
            System.out.println("3. Customer Registration");
            System.out.println("4. Exit");
            int choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1 -> adminLogin();
                case 2 -> customerLogin();
                case 3 -> registerCustomer();
                case 4 -> { System.out.println("Thank you for using AMS!"); return; }
                default -> System.out.println("Invalid choice");
            }
        }
    }

    static void adminLogin() {
        System.out.print("Admin Username: ");
        String username = scanner.nextLine();
        System.out.print("Password: ");
        String password = scanner.nextLine();
        if (username.equals("admin") && password.equals("admin123")) adminMenu();
        else System.out.println("Invalid admin credentials.");
    }

    static void customerLogin() {
        System.out.print("Enter User ID: ");
        int id = scanner.nextInt(); scanner.nextLine();
        System.out.print("Enter Password: ");
        String pwd = scanner.nextLine();
        for (Customer c : customers) {
            if (c.getUserId() == id && c.getPassword().equals(pwd)) {
                customerMenu(c);
                return;
            }
        }
        System.out.println("Invalid credentials.");
    }

    static void registerCustomer() {
        try {
            int id = customerCounter++;
            System.out.print("User Name: "); String name = scanner.nextLine();
            System.out.print("Password: "); String pwd = scanner.nextLine();
            System.out.print("Phone: "); long phone = scanner.nextLong(); scanner.nextLine();
            System.out.print("Email ID: "); String email = scanner.nextLine();
            System.out.print("DOB (dd-MM-yyyy): "); String dobStr = scanner.nextLine();
            Date dob = new SimpleDateFormat("dd-MM-yyyy").parse(dobStr);
            Customer cust = new Customer(id, name, pwd, phone, email, dob);
            customers.add(cust);
            System.out.println("Registered Successfully! Your ID is: " + id);
        } catch (Exception e) {
            System.out.println("Error in registration.");
        }
    }

    static void adminMenu() {
        while (true) {
            System.out.println("\nAdmin Menu");
            System.out.println("1. Add Carrier");
            System.out.println("2. Exit");
            int ch = scanner.nextInt(); scanner.nextLine();
            switch (ch) {
                case 1 -> addCarrier();
                case 2 -> { return; }
                default -> System.out.println("Invalid Choice");
            }
        }
    }

    static void addCarrier() {
        try {
            int id = carrierCounter++;
            System.out.print("Carrier Name: "); String name = scanner.nextLine();
            System.out.print("Discount for 30-day advance: "); int d30 = scanner.nextInt();
            System.out.print("Discount for 60-day advance: "); int d60 = scanner.nextInt();
            System.out.print("Discount for 90-day advance: "); int d90 = scanner.nextInt();
            System.out.print("Bulk Booking Discount: "); int bulk = scanner.nextInt();
            System.out.print("Refund 2 days before: "); int r2 = scanner.nextInt();
            System.out.print("Refund 10 days before: "); int r10 = scanner.nextInt();
            System.out.print("Refund 20+ days before: "); int r20 = scanner.nextInt();
            System.out.print("Silver Discount: "); int silver = scanner.nextInt();
            System.out.print("Gold Discount: "); int gold = scanner.nextInt();
            System.out.print("Platinum Discount: "); int platinum = scanner.nextInt();
            scanner.nextLine();

            Carrier carrier = new Carrier(id, name, d30, d60, d90, bulk, r2, r10, r20, silver, gold, platinum);
            carriers.add(carrier);
            System.out.println("Carrier Saved Successfully with ID: " + id);
        } catch (Exception e) {
            System.out.println("Failed to save carrier.");
        }
    }

    static void customerMenu(Customer c) {
        while (true) {
            System.out.println("\nCustomer Menu");
            System.out.println("1. Edit Profile");
            System.out.println("2. Exit");
            int ch = scanner.nextInt(); scanner.nextLine();
            switch (ch) {
                case 1 -> editProfile(c);
                case 2 -> { return; }
                default -> System.out.println("Invalid Choice");
            }
        }
    }

    static void editProfile(Customer c) {
        try {
            System.out.print("New User Name: "); String name = scanner.nextLine();
            System.out.print("New Password: "); String pwd = scanner.nextLine();
            System.out.print("Phone: "); long phone = scanner.nextLong(); scanner.nextLine();
            System.out.print("Email ID: "); String email = scanner.nextLine();
            System.out.print("Address 1: "); String a1 = scanner.nextLine();
            System.out.print("Address 2: "); String a2 = scanner.nextLine();
            System.out.print("City: "); String city = scanner.nextLine();
            System.out.print("State: "); String state = scanner.nextLine();
            System.out.print("Country: "); String country = scanner.nextLine();
            System.out.print("Zip Code: "); long zip = scanner.nextLong(); scanner.nextLine();
            System.out.print("DOB (dd-MM-yyyy): "); String dobStr = scanner.nextLine();
            Date dob = new SimpleDateFormat("dd-MM-yyyy").parse(dobStr);
            c.editProfile(name, pwd, phone, email, a1, a2, city, state, country, zip, dob);
            System.out.println("Profile updated successfully.");
        } catch (Exception e) {
            System.out.println("Error updating profile.");
        }
    }
}